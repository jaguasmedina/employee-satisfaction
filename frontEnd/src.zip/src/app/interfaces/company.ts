export interface Company {
    "id": number;
    "name": string;
    "logo_url": string;
    "created_at": string;
    "updated_at": string;
}
